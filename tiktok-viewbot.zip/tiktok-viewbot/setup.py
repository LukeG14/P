from os import system

system('pip install selenium')
print('\nFinished.')
system('pause >NUL')
